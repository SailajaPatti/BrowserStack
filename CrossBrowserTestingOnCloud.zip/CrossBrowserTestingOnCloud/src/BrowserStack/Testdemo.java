package BrowserStack;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Testdemo {
	
	@Test
	
	public void sample() throws MalformedURLException {
		
		//The goal is that we need to run the tests by required Browser and it's version and OS and it's version
		//by using BrowserStack 
		
		//go to official Website of BrowserStack
		//BrowserStack>Free trial>login>Automate>Select Selenium TestNG
		/*1.Sample Project
		2.create .yml file in project level which contains userName and accessKey parameters (you can get thses file from ur account)in the browserstack.yml file, available in the root directory, to authenticate your tests on BrowserStack since it not open sorce rt for 1st one hour it give free trial after that it will charge if u still wanat to use.
		also where u can define all ur browser and OS Specifications*/
		//here u can configure 3 platforms whch means the test needs to run on those 3 platforms  if there are 2 tests u need to confire at
		//time how many tests need to run on one platform in .yml file
		
		
      //since if u r running remotely or cloud we can't directly use ChromeDriver Class to implement the interface WebDriver
      //we need to use RemoteWebDriver class with 2 args by passing 1 args as where it needs to execute and caps object of Browser,OS Specification
      //earlier for Grid we provided the link where the Grid is configured like that BrowserStack guys provided one
      //one URL "https://hub.browserstack.com/wd/hub" in their official documentation where the tests r running remotely
      //we need to inject all specifications which are presentin .yml file into our project to identify
		
		 MutableCapabilities caps=new MutableCapabilities(); //which works same as DesiredCapabilities
//We need to give an idea .yml file to the caps object for there is a jar file which can take care of read the data
//from .yml file
		WebDriver driver=new RemoteWebDriver(new URL("https://hub.browserstack.com/wd/hub"), caps);
		driver.get("https://rahulshettyacademy.com");
		Assert.assertTrue(driver.getTitle().matches("Rahul Shetty Academy"));
	}
//3.so add jar into pom.xml and add plugin into pom.xml whenever u run ur project as a Maven project it will search for testng file in pom.xml if it found in the puginn since we added rt
//also in pulgin we added jar rt so jar Also invoked and fetch the data from .yml meaNwhile compiler goto testng.Xml file and run the tests This process we r aware rt how testng file runs the testcases
//then run ur tests u can run ur projects as maven simply right click >Run as>Maven tests or in cmd mvn run			

}
